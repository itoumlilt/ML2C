print_string "hello world!\n";

